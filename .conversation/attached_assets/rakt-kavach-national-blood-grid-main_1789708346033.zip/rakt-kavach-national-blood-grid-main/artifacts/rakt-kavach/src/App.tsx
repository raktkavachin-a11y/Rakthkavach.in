import { Switch, Route, Router as WouterRouter } from "wouter";
import NotFound from "./pages/NotFound";
import { LanguageProvider } from "@/lib/language-context";
import GatewayPage from "@/pages/GatewayPage";
import DonorDashboard from "@/pages/DonorDashboard";
import HospitalDashboard from "@/pages/HospitalDashboard";
import LabDashboard from "@/pages/LabDashboard";
import AuthorityDashboard from "@/pages/AuthorityDashboard";
import FounderDashboard from "@/pages/FounderDashboard";
import SOSPage from "@/pages/SOSPage";
import AdvancedModulesPage from "@/pages/AdvancedModulesPage";
import AllModulesPage from "@/pages/AllModulesPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={GatewayPage} />
      <Route path="/donor" component={DonorDashboard} />
      <Route path="/hospital" component={HospitalDashboard} />
      <Route path="/lab" component={LabDashboard} />
      <Route path="/authority" component={AuthorityDashboard} />
      <Route path="/founder" component={FounderDashboard} />
      <Route path="/sos" component={SOSPage} />
      <Route path="/modules" component={AdvancedModulesPage} />
      <Route path="/all-modules" component={AllModulesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-zinc-950 text-white relative">
        <WouterRouter base={import.meta.env.BASE_URL ? import.meta.env.BASE_URL.replace(/\/$/, "") : ""}>
          <Router />
        </WouterRouter>
      </div>
    </LanguageProvider>
  );
}

export default App;
